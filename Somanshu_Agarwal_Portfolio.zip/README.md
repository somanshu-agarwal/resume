# Somanshu Agarwal Portfolio (Hybrid Balance)
A Notion-style minimalist portfolio showcasing your work, projects, and career.

## How to Use
1. Open `index.html` to view locally.
2. Edit files in the `data/` folder to update content.
3. Deploy easily on GitHub Pages or Netlify.

## Deployment
To host on GitHub Pages:
- Create a repo and push this folder.
- Enable Pages in Settings -> Pages -> Source: `main / (root)`.

Your portfolio will be live at:
https://<your-username>.github.io/portfolio
