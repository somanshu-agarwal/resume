document.addEventListener('DOMContentLoaded', () => {
  fetch('data/profile.json')
    .then(res => res.json())
    .then(profile => {
      document.getElementById('name').textContent = profile.name;
      document.getElementById('title').textContent = profile.title;
    });
});
